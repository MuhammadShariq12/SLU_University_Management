/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author uzair
 */
public interface  CommonFunctions {
     //Methods which are used in each class and being overriden
    public void WriteToFile();
    public void ReadFromFile();
    public void FieldValidator();
    public void ClearTexts();
    
}
